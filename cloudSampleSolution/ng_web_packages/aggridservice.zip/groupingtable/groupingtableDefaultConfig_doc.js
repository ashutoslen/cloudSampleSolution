/**
 * Creates an empty toolpanel configuration object
 * @return {toolPanelConfig}
 */
function createToolPanelConfig() {
}

/**
 * Creates an empty icon configuration object
 * @return {iconConfig}
 */
function createIconConfig() {
}

/**
 * Creates an empty mainMenuItems configuration object
 * @return {mainMenuItemsConfig}
 */
function createMainMenuItemsConfig() {
}
